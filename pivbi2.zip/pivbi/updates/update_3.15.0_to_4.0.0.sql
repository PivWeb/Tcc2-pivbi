-- -----------------------------------------------------
-- Table `migrations`
-- -----------------------------------------------------
CREATE TABLE `migrations` (
    `version` BIGINT(20) NOT NULL
);

INSERT INTO `migrations`(`version`) VALUES ('20121031100537');
