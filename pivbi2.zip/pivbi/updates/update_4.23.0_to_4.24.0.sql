-- Alterando tabela emitente
ALTER TABLE emitente ADD cep VARCHAR(20) NULL;
